---
title: Introducción
sidebar_position: 1
---
# Introducción

Este es el PlayBook de Royal Inmuebles para la implementación de su Vecin@ Inmobiliari@.

