---
title: Propuesta Única de Valor
sidebar_position: 3
---

# Propuesta Única de Valor

**PUV PRINCIPAL:** "Somos la única inmobiliaria en Cali que te asigna un **Vecin@ Inmobiliari@**: un agente experto que vive y respira tu mismo barrio."

## Diferenciadores

**DIFERENCIADORES CLAVE:**
- Modelo hiperlocal con conocimiento profundo del territorio
- Capacidad de respuesta inigualable  
- Acompañamiento cercano y personal
- Construcción de comunidad, no solo transacciones

## Conceptos Clave

- CERCANÍA | "Estamos a 5 minutos"
- FAMILIARIDAD | "Es un@ de nosotros"
- CONOCIMIENTO | "Nos conocemos"
- RELACIONAMIENTO | "Nos ayudamos"

