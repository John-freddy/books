---
title: Historia y Manifiesto
sidebar_position: 2
---

# Historia y Manifiesto Cultural

**ORIGEN:** Royal Inmuebles nació del propósito de dejar un legado, construir una compañía que nos sobreviva y se convierta en una fuente de valor para todos los que toca.

**MANIFIESTO:** "Edificando Relaciones" - Nuestro comportamiento se guía por 5 pilares:
- Escuchar con el Corazón
- Sorprender con Intención  
- Compartir para Crecer
- Acompañar como un Guía
- Animar para Impulsar