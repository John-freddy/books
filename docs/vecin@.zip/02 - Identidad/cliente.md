---
title: Perfil del Cliente Ideal
sidebar_position: 4
---

# 4. Perfil del Cliente Ideal

**PCI PRIMARIO:** Persona que valora el trato humano y cercano por encima de todo. Busca confianza, no perfección. Quiere una relación, no una transacción.

**ANTI-PCI:** Clientes cuyo único factor de decisión es el precio, prefieren comunicación exclusivamente digital y anónima, o ven al agente como un intermediario reemplazable.