---
title: Perfil
sidebar_position: 5
---

# Perfil de L@s Vecin@s

El perfil está constituido por una serie de competencias que las agrupamos de la siguiente manera:

## Comerciales

Aunque no necesariamente tenga experiencia comercial, debe tener una experiencia comprobada de servicio al cliente.

## Comunicacionales

Debe tener competencias que le permitan comunicarse con las personas a través del teléfono, presencial y redes sociales.

## Relacionales

Es preciso que sea capaz de empatizar con las personas y sienta un compromiso real por ayudar a las personas a progresar, a realizar sus metas.

## Eticas

Un vecino va mas allá de la ética social establecida por las normas. No solo no mata, proteje la vida. No solo no roba, ayuda a cuidar. No solo no miente, ayuda a encontrar la verdad.

## Experiencia

En algunos lugares, prefieren personas con experiencia en T.A.T., debido a su experiencia en los procesos de barridos.