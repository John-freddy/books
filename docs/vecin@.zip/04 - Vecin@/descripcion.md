---
title: Descripción
sidebar_position: 1
---

# Descripción

Nuest@ vecin@ inmobiliari@ es una persona que **vive** en el territorio que atiende.

Nuestro Vecin@ tiene como objetivo ser un especialista inmobiliario que atiende localmente las necesidades de propietarios, compradores y arrendatarios.

Al vivir y trabajar en la misma zona, su condición de vecin@ le hace un miembro mas de la comunidad.

A partir de esta relación única de cercanía, confianza y colaboración, desarrollamos una serie de estrategias on-line y off-line que nos permitan posicionar a cada vecin@ de una manera única en cada comunidad.