---
title: Comunicación
sidebar_position: 4
---

# Comunicación

Estos son algunos patrones que siguen l@s vecin@s en su comunicación con prospectos, clientes, etc.

## Tono de Voz

- **CERCANA:** Lenguaje claro, tratamiento de "tú", amigable
- **CONFIABLE:** Directa, honesta, transparente
- **HUMANA:** Empática, reconoce emociones, interés genuino
- **EXPERTA:** Demuestra conocimiento con seguridad y claridad

## Orden de preferencia de atención

1. Presencial
2. Telefónica
3. WhatsApp
4. Correo