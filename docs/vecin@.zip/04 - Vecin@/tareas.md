---
title: Tareas
sidebar_position: 2
---

# Tareas de L@s Vecin@s

Debido a que la especialización se está llevando a cabo a nivel de territorio, en cuanto a las tareas, l@s vecin@s podrán atender todo el mercado existente en el vecindario.

## Captación y Colocación

Podrán realizar tareas de Captación y Colocación.

Sólo en el caso de la colocación de ventas, no estarán encargados del proceso de negociación, recolección de documentos y elaboración de la promesa de compra-venta.

Notas:
1. Siempre procuramos la captación en exclusiva
2. Admitimos la no exclusividad en arrendamientos
3. Las ventas sólo se captan en exclusiva

### Ventas y Arrendamientos

Tendrán acceso a procesos de alquiler y ventas.

# Vivienda y Comercial

Trabajarán tanto con los inmuebles para vivienda como comerciales.

