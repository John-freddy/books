---
title: Agentes
sidebar_position: 2
---

# Los Agentes

## Agentes

Los Agentes de inteligencia artificial son un instrumento esencial en la operación cotidiana de l@s vecin@s, debido a que se constituyen en herramientas de trabajo que permiten mejorar la precisión y disminuir los tiempos de trabajo.

## Agentes Disponibles

Los agentes disponibles se encuentran en la tienda de GPT's y son los siguientes:

1. **ANALISIS DE CERTIFICADOS DE TRADICIÓN**: Este agente permite hacer una primer revisión de los certificados de tradición para así, saber si, de manera preliminar, existe alguna limitación para la actividad que se planea realizar con el inmueble.
2. **LEY 820+**: Permite conocer la ley 820 y demás normas que reglamentan el alquier de los inmuebles en la legislación colombiana.