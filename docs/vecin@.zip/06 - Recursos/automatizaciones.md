---
title: Automatizaciones
sidebar_position: 3
---

# Automatizaciones

Automatizaciones con las que contamos actualmente:

**NATALIA | Búsqueda de Inmuebles**

Natalia es la automatización que permite que todos los requerimientos que hacen los prospectos a través de las lineas de whatsapp sobre un inmueble que está disponible en la compañía sean atendidos inicialmente por una inteligencia artificial 24/7.

Esta automatización cuenta con el respaldo de una setter que califica inicialmente los leads y los canaliza a l@s vecin@s.


