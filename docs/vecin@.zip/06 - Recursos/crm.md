---
title: C.R.M.
sidebar_position: 1
---

# C.R.M.

## Plande Trabajo y C.R.M.

El C.R.M. es el nucleo de la gestión de la rutina de l@s Vecin@s.

La estructura y el orden se obtiene se obtiene al combinar el **plan de trabajo** y el **C.R.M.** como herramienta de implementación.

## Rutina de L@s Veci@s

En general, l@s veci@s, en su cotidianidad inmobiliaria realizan estas actividades:

1. Prospectar
2. Contactar
3. Visitar

El C.R.M. permite estas actividades se dejen documentadas y posteriormente, provee los recursos para recordar las actividades que han sido programadas.

## Conclusión

El uso del C.R.M. es **mandatorio** para el **éxito** del programa.

