---
title: Abogados
sidebar_position: 1
---

# Respaldo Legal

Con el fin de asegurar que todas las actuaciones de la compañía estén siguiendo el marco legal vigente, la compañía cuenta con una empresa de abogados que prestan su asesoría de manera preventiva y reactiva a las actuaciones de la empresa y sus colaboradores.