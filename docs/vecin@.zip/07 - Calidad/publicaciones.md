---
title: Publicaciones de Inmuebles
sidebar_position: 1
---

# Estándares de Calidad para las publicaciones

- **Fotos:** Mínimo 15 fotografías profesionales por propiedad
- **Video:** Recorrido corto formato reel/short obligatorio
- **Descripción:** Texto persuasivo y humano, cero errores ortográficos