---
title: Atención
sidebar_position: 2
---

# Calidad en la atención

## Respuesta a prospectos

En ningún caso, la atención a un requerimiento de un prospecto debería tomar mas de 2 horas.

## FeedBack a propietarios

El feedback a propietarios debe realizarse semanalmente.