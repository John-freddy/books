---
title: Entrenamiento
sidebar_position: 1
---

# Sistema de Entrenamiento

## El Sistema

El entrenamiento comercial del equipo se realizará a través del Sistema LucUrna.

El Gerente Comercial será el encargado de compartir de manera general el entrenamiento y serán los coordinadores los encargados de la implementación cotidiana.

## Reuniones Semanales

En las reuniones semanales se dedican 30 minutos a revisar casos de uso.