---
title: Generalidades | Captación en Arrendamientos
sidebar_position: 1
---

# Generalidades

Estas son algunas generalidades del proceso de captación de arrendamientos:

## Exclusividad

Aunque siempre procuramos la exclusividad, en este caso, podemos hacer la captación de arrendamientos sin exclusividad.

La captación en ventas, siempre la haremos en exclusiva.
