---
title: Gestión de la Rutina
sidebar_position: 3
---

# Gestión de la Rutina

Usaremos un modelo general de gestión de la rutina que podrá implementarse en todas las áreas de la compañía.

Los componentes básicos del modelo son:

1. Indicadores
   1. Gestión
   2. Desempeño
2. Tableros de Control
3. Cadencia de rendición de cuentas


